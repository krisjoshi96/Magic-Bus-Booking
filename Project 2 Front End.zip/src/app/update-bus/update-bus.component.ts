import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Bus } from '../bus';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-update-bus',
  templateUrl: './update-bus.component.html',
  styleUrls: ['./update-bus.component.css']
})
export class UpdateBusComponent implements OnInit {
  id!:number;
  bus: Bus=new Bus();

  constructor(private busService:BusService,private router :Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id =this.route.snapshot.params[`id`];
    this.busService.getBusById(this.id).subscribe(data=>
      {this.bus=data;},
      
      error =>console.log(error));
      
  }








saveBus(){
this.busService.createBus(this.bus).subscribe(data =>{
  console.log(data);
  this.goToBusList();
},
error =>console.log(error));

}



goToBusList(){

this.router.navigate([`/buses`]);

}


  onSubmit(){
   this.busService.updateBus(this.id,this.bus).subscribe( data=>
   {this.goToBusList();
  }, 
    error=>console.log(error));
    

  }
}
