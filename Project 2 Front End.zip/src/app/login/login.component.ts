import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Login=new Login();

  constructor(private loginService:LoginService,private router :Router) { }

  ngOnInit(): void {
  }





goToBusList(){

this.router.navigate([`/createBuses`]);

}


  onSubmit(){
    interface user{
      id:string;
      name:string;
      email:string;
      password:string;
      gender:string;
      phoneNo:number;


    }
    this.loginService.SubmitLogin(this.login).subscribe(data =>{
      if(data ==null)
      alert("Invalid User Name Or Password");
      else{

      console.log(data);
     // let myObject:user=JSON.parse(data);
      
      this.goToBusList();
    }
    },
    error =>console.log(error));
    
    }
}



