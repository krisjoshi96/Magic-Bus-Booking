import { NumberSymbol } from "@angular/common";

export class User {
    id!: number;
    age!: number;
    email!: string;
    gender!: string;
    name!:string;
    password!: string;
    phoneNo!: number;


}
