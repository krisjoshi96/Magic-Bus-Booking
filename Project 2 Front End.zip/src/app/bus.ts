import { Time } from "@angular/common";

export class Bus {
    

    id!: number;
    busNo!: number;
    date!: string;
    destinationCity!: string;
    fare!:number;
    fromCity!: string;
    time!: string;
    userId!:number;

}

