import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from '../bus';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrls: ['./bus-list.component.css']
})
export class BusListComponent implements OnInit {

  buses!: Bus[];

  constructor(private busService:BusService,private router :Router) { }

  ngOnInit(): void {
    this.busService.getBusList().subscribe(data=>{this.buses=data});


  }

  private getBus(){
    this.busService.getBusList().subscribe(data=>{this.buses=data})
  }

  addBus():void {
  

      this.router.navigate([`/createBuses`]);
  }

  updateBus(id: number){

      this.router.navigate([`updateBus`,id])

  }

  deleteBus(id:number){
    this.busService.deleteBus(id).subscribe( data=>{
      console.log(data);
      this.getBus();
    }
      )

  }

}
