import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bus } from './bus';

@Injectable({
  providedIn: 'root'
})
export class BusService {
  private baseURL="http://localhost:8090/buses";
  private specialURL="http://localhost:8090//busesById//";
  

  constructor(private httpClient:HttpClient) { }

  getBusListById(userId:string):Observable<Bus[]>{
    return this.httpClient.get<Bus[]>(`${this.specialURL}${userId}`)

  }


  getBusList():Observable<Bus[]>{
    return this.httpClient.get<Bus[]>(`${this.baseURL}`)
  }


  createBus(bus:Bus): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`,bus);
  }
 


  getBusById(id:number):Observable<Bus>{
    return this.httpClient.get<Bus>(`${this.baseURL}/${id}`);

  }

  updateBus(id:number,bus:Bus):Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`,bus);
  }

  deleteBus(id:number):Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);

  }
}

